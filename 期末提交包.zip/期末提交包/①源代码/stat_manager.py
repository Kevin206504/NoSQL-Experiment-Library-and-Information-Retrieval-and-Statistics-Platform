# -*- coding: utf-8 -*-
"""stat_manager.py —— 统计分析模块（分类统计、学院排行、年月趋势、畅销榜）"""
from mongodb_connect import get_db

TZ = "+08:00"


def category_report():
    rows = get_db().books.aggregate([
        {"$group": {"_id": "$category", "book_count": {"$sum": 1},
                    "stock_total": {"$sum": "$stock"},
                    "avg_price": {"$avg": "$price"}, "avg_rating": {"$avg": "$rating"}}},
        {"$project": {"category": "$_id", "book_count": 1, "stock_total": 1,
                      "avg_price": {"$round": ["$avg_price", 2]},
                      "avg_rating": {"$round": ["$avg_rating", 2]}, "_id": 0}},
        {"$sort": {"book_count": -1}},
    ]).to_list(length=None)
    print("[分类统计报表]")
    for r in rows:
        print(f"  {r['category']}：藏书 {r['book_count']} / 库存 {r['stock_total']} "
              f"/ 均价 {r['avg_price']} / 均分 {r['avg_rating']}")
    return rows


def college_rank():
    rows = get_db().borrow_logs.aggregate([
        {"$group": {"_id": "$reader_card", "borrows": {"$sum": 1}}},
        {"$lookup": {"from": "readers", "localField": "_id", "foreignField": "card_no", "as": "r"}},
        {"$unwind": "$r"},
        {"$group": {"_id": "$r.college", "total": {"$sum": "$borrows"}}},
        {"$sort": {"total": -1}}, {"$limit": 5},
    ]).to_list(length=None)
    print("[学院借阅量 TOP5]")
    for i, r in enumerate(rows, 1):
        print(f"  No.{i} {r['_id']}：{r['total']} 次")
    return rows


def borrow_trend():
    rows = get_db().borrow_logs.aggregate([
        {"$group": {"_id": {"$dateToString": {"format": "%Y年", "date": "$borrow_date",
                                              "timezone": TZ}}, "count": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
    ]).to_list(length=None)
    print("[借阅趋势（按年，时区 +08:00）]")
    for r in rows:
        print(f"  {r['_id']}：{r['count']} 本")
    return rows


def bestseller(n: int = 10):
    rows = get_db().borrow_logs.aggregate([
        {"$group": {"_id": "$book_isbn", "times": {"$sum": 1}}},
        {"$sort": {"times": -1}}, {"$limit": n},
        {"$lookup": {"from": "books", "localField": "_id", "foreignField": "isbn", "as": "b"}},
        {"$unwind": "$b"},
        {"$project": {"_id": 0, "title": "$b.title", "times": 1,
                      "floor": "$b.location.floor", "shelf": "$b.location.shelf"}},
    ]).to_list(length=None)
    print(f"[畅销榜 TOP {n}]（含馆藏位置）")
    for i, r in enumerate(rows, 1):
        print(f"  No.{i} {r['title']}：{r['times']} 次 @ {r.get('floor', '')} {r.get('shelf', '')}")
    return rows
