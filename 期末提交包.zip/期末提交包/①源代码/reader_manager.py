# -*- coding: utf-8 -*-
"""reader_manager.py —— 读者管理模块（读者列表、学院统计、等级分布）"""
from mongodb_connect import get_db


def list_readers(limit: int = 20):
    docs = list(get_db().readers.find({}, {"_id": 0}).limit(limit))
    print(f"[读者列表] 共 {get_db().readers.count_documents({})} 条，显示前 {len(docs)} 条：")
    for d in docs:
        fav = "、".join(d.get("fav_categories", [])) or "（未填写）"
        print(f"  [{d.get('card_no')}] {d.get('name')} | {d.get('college')} | {d.get('level')} | 邮箱: {d.get('email') or '无'}")
    return docs


def stat_by_college():
    rows = sorted(((c, get_db().readers.count_documents({"college": c})) for c in get_db().readers.distinct("college")),
                  key=lambda x: -x[1])
    print("[学院统计]")
    for c, n in rows:
        print(f"  {c}: {n} 人")
    return rows


def level_distribution():
    levels = get_db().readers.distinct("level")
    total = get_db().readers.count_documents({})
    print(f"[借阅等级分布]（共 {total} 人）")
    for lv in levels:
        n = get_db().readers.count_documents({"level": lv})
        print(f"  {lv}: {n} 人（{n / total:.0%}）")
