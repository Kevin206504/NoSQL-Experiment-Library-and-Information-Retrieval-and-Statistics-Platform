# -*- coding: utf-8 -*-
"""main.py —— 智慧图书馆数字资源平台 主程序（期末项目 ST-4）

菜单式交互，17 项功能覆盖：检索、统计、更新、删除、GridFS 上传下载校验、
操作日志查询、数据导出。启动打印连接状态与集合概览；变更打印受影响文档数；
退出前关闭连接。连接参数全部来自 config.json，无硬编码。
"""
import json
import os

from mongodb_connect import close_client, conf_path, conf_value, get_client, get_db
import audit
import book_manager
import reader_manager
import borrow_manager
import stat_manager
import file_manager


def show_startup():
    print("=" * 64)
    print("    智慧图书馆数字资源平台 v1.0（MongoDB 7.0 / PyMongo）")
    print("=" * 64)
    try:
        db = get_db()
        ping = get_client().admin.command("ping")
        rs = conf_value("replicaSet")
        target = conf_value("host") + (f"（replicaSet={rs}）" if rs
                                       else f":{conf_value('port', '27017')}")
        print(f"[连接状态] 已连接 {target}（账号 {conf_value('user')}），ping={ping['ok']}")
        print("[集合概览]")
        for name, label in [("books", "图书"), ("readers", "读者"),
                            ("borrow_logs", "借阅流水"), ("category_stats", "分类统计"),
                            ("audit_logs", "操作日志")]:
            print(f"  {label}({name}): {db[name].count_documents({})} 条")
        fs_count = db["fs.files"].count_documents({})
        print(f"  电子书文件(fs.files): {fs_count} 个")
    except Exception as e:
        print(f"[连接状态] 连接失败：{e}")
        raise SystemExit(1)


MENU = """
-------------------- 功能菜单 --------------------
  1. 图书检索（书名模糊）          2. 评分排行 TOP 10
  3. 新书入库                      4. 图书下架
  5. 库存调整                      6. 读者统计（学院/等级）
  7. 借阅登记                      8. 归还处理
  9. 逾期借阅查询                 10. 分类统计报表
 11. 借阅趋势分析                 12. 畅销榜 / 学院借阅排行
 13. 电子书批量上传 GridFS        14. 按书名下载电子书并校验
 15. GridFS 文件清单              16. 操作日志（最近 100 条）
 17. 导出数据文件                 0. 退出
--------------------------------------------------"""


def ask(prompt, default=""):
    v = input(prompt).strip()
    return v or default


def export_data():
    """导出统计结果集合为 JSON 文件（写入 audit_logs）"""
    out_dir = conf_path("download_dir")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "category_stats_export.json")
    rows = list(get_db().category_stats.find({}, {"_id": 0}))
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2, default=str)
    audit.log_action("导出数据", out, f"导出 category_stats {len(rows)} 条")
    print(f"[导出数据] 已导出 {len(rows)} 条到 {out}")


def handle(choice):
    if choice == "1":
        kw = ask("请输入书名关键字: ")
        if kw:
            book_manager.search_by_title(kw)
    elif choice == "2":
        book_manager.top_rating(10)
    elif choice == "3":
        isbn = ask("ISBN: ")
        title = ask("书名: ")
        if not (isbn and title):
            print("[新书入库] ISBN 和书名不能为空")
            return
        book = {"isbn": isbn, "title": title, "author": ask("作者: "),
                "publisher": ask("出版社: "), "category": ask("类别: "),
                "price": float(ask("定价 [0]: ", "0")), "stock": int(ask("库存 [0]: ", "0")),
                "rating": 0.0, "borrow_count": 0}
        book_manager.insert_book(book)
    elif choice == "4":
        isbn = ask("要下架图书的 ISBN: ")
        if ask("确认下架该图书？(y/n): ").lower() == "y":
            book_manager.delete_book(isbn)
        else:
            print("[图书下架] 已取消")
    elif choice == "5":
        isbn = ask("图书 ISBN: ")
        delta = int(ask("库存变化量（正入库/负出库）: "))
        book_manager.update_stock(isbn, delta)
    elif choice == "6":
        reader_manager.stat_by_college()
        reader_manager.level_distribution()
    elif choice == "7":
        card = ask("读者借阅证号: ")
        isbn = ask("图书 ISBN: ")
        if card and isbn:
            borrow_manager.borrow_book(card, isbn)
        else:
            print("[借阅登记] 借阅证号和 ISBN 不能为空")
    elif choice == "8":
        card = ask("读者借阅证号（可回车跳过）: ")
        isbn = ask("图书 ISBN（可回车跳过）: ")
        if not (card or isbn):
            print("[归还处理] 至少提供借阅证号或 ISBN 之一")
            return
        borrow_manager.return_book(card_no=card or None, isbn=isbn or None)
    elif choice == "9":
        borrow_manager.find_overdue()
    elif choice == "10":
        stat_manager.category_report()
    elif choice == "11":
        stat_manager.borrow_trend()
    elif choice == "12":
        stat_manager.bestseller(10)
        stat_manager.college_rank()
    elif choice == "13":
        file_manager.upload_all()
    elif choice == "14":
        kw = ask("请输入书名或关键字（如 Python）: ")
        if kw:
            file_manager.download_by_title(kw)
    elif choice == "15":
        file_manager.list_files()
    elif choice == "16":
        rows = audit.recent(100)
        if not rows:
            print("[操作日志] 暂无记录")
        else:
            print(f"[操作日志] 最近 {len(rows)} 条：")
            for r in rows:
                print(f"  {r['ts']:%Y-%m-%d %H:%M:%S}  {r['action']}  {r['target']}  {r['detail']}")
    elif choice == "17":
        export_data()
    elif choice == "0":
        return
    else:
        print("[提示] 无效的菜单编号，请重新选择")


def main():
    show_startup()
    audit.ensure_index()
    while True:
        print(MENU)
        choice = ask("请选择功能编号: ")
        if choice == "0":
            print("正在关闭数据库连接...")
            close_client()
            print("已退出，再见！")
            break
        try:
            handle(choice)
        except ValueError as e:
            print(f"[输入错误] {e}")
        except Exception as e:
            print(f"[操作失败] {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
