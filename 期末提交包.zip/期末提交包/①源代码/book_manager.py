# -*- coding: utf-8 -*-
"""book_manager.py —— 图书管理模块（增删改查、条件检索、评分排行）"""
import re

import audit
from mongodb_connect import get_db

_PROJ = {"_id": 0, "isbn": 1, "title": 1, "author": 1, "publisher": 1,
         "category": 1, "price": 1, "stock": 1, "rating": 1}


def _show(d):
    loc = d.get("location") or {}
    print(f"  [{d.get('isbn')}] {d.get('title')} | {d.get('category')} | ￥{d.get('price')} "
          f"| 库存{d.get('stock')} | 评分{d.get('rating')} | {loc.get('floor', '')} {loc.get('shelf', '')}")


def search_by_title(kw: str):
    docs = list(get_db().books.find({"title": {"$regex": re.escape(kw)}}, _PROJ).limit(20))
    if not docs:
        print("[检索] 没有符合条件的图书")
    else:
        print(f"[检索] 匹配 {get_db().books.count_documents({'title': {'$regex': re.escape(kw)}})} 条，显示前 {len(docs)} 条：")
        for d in docs:
            _show(d)
    return docs


def top_rating(n: int = 10):
    docs = list(get_db().books.find({}, _PROJ).sort("rating", -1).limit(n))
    print(f"[评分排行 TOP {n}]")
    for i, d in enumerate(docs, 1):
        print(f"  No.{i} ", end="")
        _show(d)
    return docs


def insert_book(book: dict) -> bool:
    if get_db().books.find_one({"isbn": book.get("isbn")}):
        print("[新书入库] 该 ISBN 已存在（唯一索引保护）")
        return False
    get_db().books.insert_one(book)
    audit.log_action("新增图书", book.get("isbn", ""), book.get("title", ""))
    print(f"[新书入库] 受影响文档数: 1（{book.get('title')}）")
    return True


def delete_book(isbn: str) -> bool:
    doc = get_db().books.find_one({"isbn": isbn})
    if not doc:
        print("[图书下架] 未找到该 ISBN")
        return False
    get_db().books.delete_one({"isbn": isbn})
    audit.log_action("删除图书", isbn, doc.get("title", ""))
    print(f"[图书下架] 受影响文档数: 1（{doc.get('title')}）")
    return True


def update_stock(isbn: str, delta: int):
    r = get_db().books.update_one({"isbn": isbn}, {"$inc": {"stock": delta}})
    print(f"[库存调整] 匹配 {r.matched_count} 条，实际修改 {r.modified_count} 条")
    return r
