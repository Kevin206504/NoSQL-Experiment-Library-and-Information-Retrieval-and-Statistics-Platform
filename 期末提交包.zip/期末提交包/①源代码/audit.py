# -*- coding: utf-8 -*-
"""audit.py —— 操作日志模块（期末项目 ST-4）

每次新增 / 删除 / 导出等关键操作写入 audit_logs 一条记录，
字段设计见任务二：ts（时间）、action（动作）、operator（操作者）、
target（对象）、detail（明细）。集合上建 ts 降序索引，支撑按时间
倒序查询最近 100 条操作。
"""
from datetime import datetime

from mongodb_connect import get_db

OPERATOR = "writer_acc"   # 平台当前操作账号


def log_action(action: str, target: str, detail: str = "") -> None:
    doc = {"ts": datetime.now(), "action": action,
           "operator": OPERATOR, "target": target, "detail": detail}
    get_db().audit_logs.insert_one(doc)


def ensure_index() -> None:
    get_db().audit_logs.create_index([("ts", -1)])


def recent(n: int = 100):
    """按时间倒序返回最近 n 条操作"""
    ensure_index()
    return list(get_db().audit_logs.find({}, {"_id": 0}).sort("ts", -1).limit(n))
