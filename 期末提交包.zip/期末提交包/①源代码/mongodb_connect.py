# -*- coding: utf-8 -*-
"""mongodb_connect.py —— 统一连接模块（期末项目 ST-4）

连接参数全部来自同目录 config.json，代码中不硬编码任何主机/端口/账号/路径，
换机器时只需修改配置文件。模块级单例，供全部业务模块与主程序调用。
"""
import json
import os

from gridfs import GridFSBucket
from pymongo import MongoClient

_CONF_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
_client = None
_db = None
_fs = None


def _conf() -> dict:
    with open(_CONF_PATH, encoding="utf-8") as f:
        return json.load(f)


def get_db():
    """获取业务数据库对象（首次调用时按 config.json 建立连接）

    兼容两种配置形态：
    - 单机：host + port
    - 副本集/分片：host 为种子列表（host1:port,host2:port,...）+ replicaSet
    """
    global _client, _db, _fs
    if _db is None:
        c = _conf()
        kwargs = dict(
            username=c["user"],
            password=os.environ.get("MONGO_PASSWORD", c["password"]),
            authSource=c["authSource"], serverSelectionTimeoutMS=5000,
        )
        if c.get("replicaSet"):
            kwargs["host"] = c["host"]
            kwargs["replicaSet"] = c["replicaSet"]
        else:
            kwargs["host"] = c["host"]
            kwargs["port"] = int(c.get("port", 27017))
        _client = MongoClient(**kwargs)
        _db = _client[c["db"]]
        _fs = GridFSBucket(_db)
    return _db


def get_client() -> MongoClient:
    """获取 MongoClient 实例（模块级单例）"""
    get_db()
    return _client


def get_fs() -> GridFSBucket:
    """获取 GridFS 文件桶"""
    get_db()
    return _fs


def conf_value(key: str, default: str = "") -> str:
    return _conf().get(key, default)


def conf_path(key: str, default: str = "") -> str:
    """取路径类配置：相对路径一律相对 config.json 所在目录解析，保证整包可移动"""
    v = _conf().get(key, default)
    if v and not os.path.isabs(v):
        v = os.path.normpath(os.path.join(os.path.dirname(_CONF_PATH), v))
    return v


def close_client() -> None:
    global _client, _db, _fs
    if _client is not None:
        _client.close()
        _client = _db = _fs = None
