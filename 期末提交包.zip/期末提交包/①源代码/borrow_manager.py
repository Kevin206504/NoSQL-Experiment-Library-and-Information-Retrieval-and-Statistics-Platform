# -*- coding: utf-8 -*-
"""borrow_manager.py —— 借阅管理模块（借阅登记、归还处理、逾期查询）

borrow_logs 在任务二中设计为普通集合（支撑任务六分片），
因此归还处理可直接使用 update_many 修改 status / return_date。
"""
from datetime import datetime, timedelta

from mongodb_connect import get_db

BORROW_DAYS = 30


def borrow_book(card_no: str, isbn: str):
    doc = {"borrow_date": datetime.now(), "reader_card": card_no,
           "book_isbn": isbn, "status": "借出"}
    r = get_db().borrow_logs.insert_one(doc)
    print(f"[借阅登记] 受影响文档数: 1（{card_no} 借出 {isbn}）")
    return r


def return_book(card_no: str = None, isbn: str = None):
    query = {"status": "借出"}
    if card_no:
        query["reader_card"] = card_no
    if isbn:
        query["book_isbn"] = isbn
    r = get_db().borrow_logs.update_many(
        query, {"$set": {"status": "已归还", "return_date": datetime.now()}})
    print(f"[归还处理] 匹配 {r.matched_count} 条，实际修改 {r.modified_count} 条")
    return r


def find_overdue(days: int = BORROW_DAYS):
    deadline = datetime.now() - timedelta(days=days)
    rows = list(get_db().borrow_logs.find(
        {"$or": [{"status": "逾期"}, {"status": "借出", "borrow_date": {"$lt": deadline}}]},
        {"_id": 0}))
    if not rows:
        print(f"[逾期查询] 查询无结果：没有逾期或借出超过 {days} 天的记录")
    else:
        print(f"[逾期查询] 共 {len(rows)} 条")
        for d in rows[:20]:
            print(f"  {d['reader_card']} 借 {d['book_isbn']} 于 {d['borrow_date']:%Y-%m-%d}，状态: {d['status']}")
        if len(rows) > 20:
            print(f"  ...（其余 {len(rows) - 20} 条省略）")
    return rows
