# -*- coding: utf-8 -*-
"""gridfs_verify.py —— GridFS 六文件批量下载字节校验（任务四/七证据脚本）

把 GridFS 中全部文件逐个下载到 download_dir（下载_<文件名>），
与②数据文件/GridFS源文件 中的源文件逐字节比对（大小 + MD5），
结果打印并写入 download_dir/下载校验记录.txt。可反复重跑。
用法: python gridfs_verify.py
"""
import hashlib
import os
from datetime import datetime

from mongodb_connect import conf_path, get_fs

SOURCE_DIR = conf_path("gridfs_source_dir")
DOWNLOAD_DIR = conf_path("download_dir")


def md5(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def main() -> None:
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    rows = list(get_fs().find({}))
    lines = [f"GridFS 下载校验记录  {datetime.now():%Y-%m-%d %H:%M:%S}",
             f"GridFS 文件数: {len(rows)}", ""]
    ok_all = True
    for g in sorted(rows, key=lambda x: x.filename):
        local = os.path.join(DOWNLOAD_DIR, "下载_" + g.filename)
        with open(local, "wb") as f:
            get_fs().download_to_stream(g._id, f)
        src = os.path.join(SOURCE_DIR, g.filename)
        size_ok = os.path.getsize(local) == g.length
        md5_ok = os.path.exists(src) and md5(local) == md5(src)
        ok = size_ok and md5_ok
        ok_all = ok_all and ok
        line = (f"{g.filename}: GridFS记录 {g.length} 字节 | 下载 {os.path.getsize(local)} 字节 | "
                f"大小{'一致' if size_ok else '不一致'} | 与源文件MD5{'一致' if md5_ok else '不一致'} | "
                f"{'通过' if ok else '失败'}")
        print("  " + line)
        lines.append(line)
    lines += ["", f"结论: {len(rows)} 个文件全部下载且字节与源文件一致 = {'是' if ok_all else '否'}"]
    rec = os.path.join(DOWNLOAD_DIR, "下载校验记录.txt")
    with open(rec, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"[GridFS 校验] {'全部通过 ✓' if ok_all else '存在失败 ✗'}，记录已写入 {rec}")


if __name__ == "__main__":
    main()