# -*- coding: utf-8 -*-
"""file_manager.py —— GridFS 电子书存储模块（期末项目 ST-4 / 第 6 章）

功能：
  upload_all()            将 3 个电子书 PDF 与 3 张封面图上传 GridFS，写入元数据
  download_by_title()     按书名查询其电子书并下载到本地，校验字节数一致
  list_files()            列出 GridFS 中全部文件（文件名、大小、上传时间、元数据）
"""
import os

from mongodb_connect import conf_path, get_db, get_fs
import audit

SOURCE_DIR = conf_path("gridfs_source_dir")
DOWNLOAD_DIR = conf_path("download_dir")


def upload_all() -> int:
    """按 manifest 对应关系上传 3 个 PDF 与 3 张封面图，元数据含 ISBN/类型/原始文件名"""
    files = sorted(os.listdir(SOURCE_DIR))
    count = 0
    for name in files:
        if name.endswith(".pdf"):
            ftype = "ebook"
        elif name.endswith(".png"):
            ftype = "cover"
        else:
            continue
        src = os.path.join(SOURCE_DIR, name)
        related = _related_isbn(name)
        with open(src, "rb") as f:
            fid = get_fs().upload_from_stream(
                name, f,
                metadata={"related_isbn": related, "file_type": ftype,
                          "original_name": name, "uploaded_by": audit.OPERATOR})
        size = os.path.getsize(src)
        print(f"  上传 {name}（{ftype}，关联 {related}，{size} 字节）-> _id {fid}")
        count += 1
    audit.log_action("GridFS上传", "gridfs", f"上传 {count} 个文件（3 PDF + 3 封面）")
    print(f"[GridFS 上传] 共上传 {count} 个文件")
    return count


def _related_isbn(name: str) -> str:
    """从文件名编号推导关联 ISBN（manifest 中 1→9787115428028, 2→9787121362726, 3→9787115546081）"""
    mapping = {"1": "9787115428028", "2": "9787121362726", "3": "9787115546081"}
    num = name.rsplit(".", 1)[0].rsplit("_", 1)[-1]
    return mapping.get(num, "")


def download_by_title(title_kw: str) -> bool:
    """按书名查询其电子书并下载，校验下载文件字节数与 GridFS 中记录一致"""
    book = get_db().books.find_one(
        {"title": {"$regex": title_kw}, "ebook_name": {"$exists": True}},
        {"_id": 0, "title": 1, "ebook_name": 1})
    if not book:
        any_match = get_db().books.find_one({"title": {"$regex": title_kw}}, {"_id": 0, "title": 1})
        if any_match:
            print(f"[下载校验] 找到与「{title_kw}」匹配的图书，但该书未关联电子书")
            print("           可尝试关联了电子书的关键字，如：Python编程")
        else:
            print(f"[下载校验] 没有找到与「{title_kw}」匹配的图书")
        return False
    fname = book["ebook_name"]
    grid_files = list(get_fs().find({"filename": fname}))
    if not grid_files:
        print(f"[下载校验] GridFS 中不存在 {fname}，请先执行上传")
        return False
    g = grid_files[0]
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    local = os.path.join(DOWNLOAD_DIR, "下载_" + fname)
    with open(local, "wb") as f:
        get_fs().download_to_stream(g._id, f)
    local_size = os.path.getsize(local)
    ok = (local_size == g.length)
    print(f"[下载校验] 书名「{book['title']}」-> {fname}")
    print(f"  GridFS 记录大小: {g.length} 字节 | 下载文件大小: {local_size} 字节 | "
          f"校验{'一致 ✓' if ok else '不一致 ✗'}")
    print(f"  已保存到: {local}")
    audit.log_action("文件下载", fname, f"下载 {local_size} 字节，校验{'一致' if ok else '不一致'}")
    return ok


def list_files():
    """列出 GridFS 全部文件：文件名、大小、上传时间、元数据"""
    rows = list(get_fs().find({}))
    print(f"[GridFS 文件清单] 共 {len(rows)} 个文件：")
    for f in rows:
        md = f.metadata or {}
        print(f"  {f.filename}  |  {f.length} 字节  |  上传时间 {f.upload_date:%Y-%m-%d %H:%M:%S}"
              f"  |  类型 {md.get('file_type', '-')}  |  ISBN {md.get('related_isbn', '-')}")
    return rows
