@echo off
chcp 936 >nul
cd /d "%~dp0"
mongosh --quiet --port 27017 --file 01_import.js
pause
