// 15b_make_shard_admin.js —— 任务六：经 mongos 创建集群管理员
// 用法（15_shard_setup.js 跑完、集群尚无任何账号时，利用 localhost 例外窗口）:
//   mongosh --port 28021 --file 15b_make_shard_admin.js
// 此后 localhost 例外关闭，导入与核验改用 shard_admin 凭据（见 run_import_mongos.bat）。

db = db.getSiblingDB("admin");
try {
  db.createUser({
    user: "shard_admin", pwd: "Shard@2026",
    roles: [ { role: "root", db: "admin" } ],
  });
  print("shard_admin（root@admin）创建完成 ✓");
} catch (e) {
  print("创建跳过（账号可能已存在）: " + e.message.substring(0, 80));
}
print("后续请使用: mongosh --port 28021 -u shard_admin -p Shard@2026 --authenticationDatabase admin");