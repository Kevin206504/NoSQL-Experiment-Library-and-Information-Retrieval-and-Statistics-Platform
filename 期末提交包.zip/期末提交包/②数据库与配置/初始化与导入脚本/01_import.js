// 01_import.js —— 任务三：建库建集合 + 导入三份数据（日期字符串转 BSON Date）
// 用法: 双击同目录 run_import_standalone.bat / run_import_mongos.bat，
//       或先 cd 到本目录再 mongosh --port <端口> --file 01_import.js
// 数据目录相对"脚本所在目录"解析（../数据文件 即提交包②内的数据文件），换机器无需改路径。

const SRC = "../数据文件";
const DATE_FIELDS = ["publish_date", "register_date", "borrow_date", "return_date"];

// 数据文件中的日期是 ISO 8601 字符串，必须转成 BSON Date（任务书明确要求）
function toDateObject(doc) {
  for (const k of DATE_FIELDS) {
    if (doc[k] && typeof doc[k] === "string") doc[k] = new Date(doc[k]);
  }
  return doc;
}

db = db.getSiblingDB("smart_library");

print("== 建库建集合（borrow_logs 按任务二设计为普通集合）==");
[["books"], ["readers"], ["borrow_logs"], ["category_stats"]].forEach(([name]) => {
  try {
    db.createCollection(name);
    print("  " + name + " 创建完成");
  } catch (e) {
    print("  " + name + " 创建跳过: " + e.message.substring(0, 70));
  }
});

function importColl(file, collName) {
  const docs = JSON.parse(fs.readFileSync(SRC + "/" + file, "utf8")).map(toDateObject);
  print("===== " + collName + "：源文件 " + docs.length + " 条 =====");
  const r1 = db.getCollection(collName).insertOne(docs[0]);
  print("insertOne acknowledged=" + r1.acknowledged);
  const r2 = db.getCollection(collName).insertMany(docs.slice(1));
  print("insertMany insertedCount=" + Object.keys(r2.insertedIds).length);
  const n = db.getCollection(collName).countDocuments({});
  print(">> " + collName + " 当前文档数: " + n + "（期望 " + docs.length + "）");
  print("");
  return n;
}

const nb = importColl("books.txt", "books");
const nr = importColl("readers.txt", "readers");
const nl = importColl("borrow_logs.txt", "borrow_logs");

print("===== 核对汇总 =====");
print("books = " + nb + "（期望 50）");
print("readers = " + nr + "（期望 30）");
print("borrow_logs = " + nl + "（期望 3000）");
print("全部一致: " + (nb === 50 && nr === 30 && nl === 3000 ? "是" : "否！！"));
