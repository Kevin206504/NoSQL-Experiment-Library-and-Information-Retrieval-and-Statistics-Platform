@echo off
chcp 936 >nul
cd /d "%~dp0"
mongosh --quiet --port 28021 -u shard_admin -p Shard@2026 --authenticationDatabase admin --file 01_import.js
pause
