// 10b_make_cluster_admin.js —— 任务五：创建集群管理员（访问控制启用前的标准路径）
// 用法（副本集处于无认证演练模式时，直接粘贴运行）:
//   mongosh "本目录/10b_make_cluster_admin.js"
// 此时认证尚未启用，创建用户无需凭据；随后启用认证，该账号即为集群管理员。

db = db.getSiblingDB("admin");
db.createUser({
  user: "cluster_admin", pwd: "Cluster@2026",
  roles: [ { role: "root", db: "admin" } ],
});
print("cluster_admin（root@admin）创建完成 ✓");
print("启用认证后请使用: mongosh -u cluster_admin -p Cluster@2026 --authenticationDatabase admin");
