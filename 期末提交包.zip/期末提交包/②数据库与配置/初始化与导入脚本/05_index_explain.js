// 05_index_explain.js —— 任务三：索引创建 + 执行计划前后对比（至少 2 条查询，含耗时）
// 用法: mongosh "本目录/05_index_explain.js"

db = db.getSiblingDB("smart_library");

function probe(collName, query) {
  const e = db.getCollection(collName).find(query).explain("executionStats");
  const s = e.executionStats;
  const w = e.queryPlanner.winningPlan;
  const stage = w.stage || (w.inputStage ? w.inputStage.stage : "?");
  const idx = (w.inputStage && w.inputStage.indexName) ? w.inputStage.indexName : "-";
  return { stage: stage, idx: idx, ms: s.executionTimeMillis,
           docs: s.totalDocsExamined, keys: s.totalKeysExamined, ret: s.nReturned };
}
function show(label, r) {
  print("  " + label + "：stage=" + r.stage + "  索引=" + r.idx
    + "  耗时=" + r.ms + "ms  检查文档=" + r.docs + "  检查索引键=" + r.keys
    + "  返回=" + r.ret);
}

const QA = { category: "计算机", price: { $gte: 40, $lte: 100 } };                    // books 复合查询
const QB = { borrow_date: { $gte: new Date("2025-01-01T00:00:00+08:00") } };          // borrow_logs 年份范围

print("===== 建索引前（COLLSCAN 基线）=====");
const a1 = probe("books", QA);       show("查询A books 类别+价格区间", a1);
const b1 = probe("borrow_logs", QB); show("查询B 流水 2025 年范围", b1);

print("\n===== 创建索引（按任务二索引清单）=====");
print("  books.isbn 唯一索引            -> " + db.books.createIndex({ isbn: 1 }, { unique: true }));
print("  books.title 单键索引          -> " + db.books.createIndex({ title: 1 }));
print("  books.category+price 复合索引 -> " + db.books.createIndex({ category: 1, price: 1 }));
print("  borrow_logs.borrow_date       -> " + db.borrow_logs.createIndex({ borrow_date: 1 }));
print("  borrow_logs.reader_card       -> " + db.borrow_logs.createIndex({ reader_card: 1 }));
print("  borrow_logs.book_isbn         -> " + db.borrow_logs.createIndex({ book_isbn: 1 }));

print("\n===== 建索引后（IXSCAN）=====");
const a2 = probe("books", QA); show("查询A books 类别+价格区间", a2);
const b2 = probe("borrow_logs", QB); show("查询B 流水 2025 年范围", b2);

print("\n===== 对比结论 =====");
print("  查询A：扫描方式 " + a1.stage + " -> " + a2.stage
  + "，检查文档 " + a1.docs + " -> " + a2.docs + "，耗时 " + a1.ms + "ms -> " + a2.ms + "ms");
print("  查询B：扫描方式 " + b1.stage + " -> " + b2.stage
  + "，检查文档 " + b1.docs + " -> " + b2.docs + "，耗时 " + b1.ms + "ms -> " + b2.ms + "ms");
print("  （books 50 条 / borrow_logs 3000 条，检查文档数是主要优化证据；耗时受机器波动影响取多次均值更稳）");

print("\n===== 当前全部索引清单 =====");
["books", "readers", "borrow_logs"].forEach(c => {
  db.getCollection(c).getIndexes().forEach(ix =>
    print("  " + c + "." + ix.name + "  key=" + JSON.stringify(ix.key) + (ix.unique ? "  [unique]" : "")));
});
