// 11_rs_status.js —— 任务五：副本集状态总览（演练模式，无认证）
// 用法: mongosh "本目录/11_rs_status.js"

print("== 副本集 rs0 节点角色 ==");
const hello = db.hello();
print("  当前连接节点: " + hello.me + (hello.isWritablePrimary ? "  [主 PRIMARY]" : "  [从 SECONDARY]"));
print("  主节点: " + hello.primary);
print("  节点列表:");
rs.status().members.forEach(m =>
  print("    " + m.name + "  state=" + m.stateStr + "  health=" + m.health));

print("\n== smart_library 数据同步核对（升级自单机，应完整保留）==");
print("  books = " + db.getSiblingDB("smart_library").books.countDocuments({}) + "（期望 50）");
print("  readers = " + db.getSiblingDB("smart_library").readers.countDocuments({}) + "（期望 30）");
print("  borrow_logs = " + db.getSiblingDB("smart_library").borrow_logs.countDocuments({}) + "（期望 3000）");
print("  GridFS fs.files = " + db.getSiblingDB("smart_library")["fs.files"].countDocuments({}) + "（期望 6）");
print("  audit_logs = " + db.getSiblingDB("smart_library").audit_logs.countDocuments({}) + " 条");
