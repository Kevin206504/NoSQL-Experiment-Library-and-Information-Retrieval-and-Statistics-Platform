# 初始化与导入脚本运行顺序

全部脚本用 mongosh 执行。**带路径的脚本（01_import.js）必须双击同目录 run_*.bat，
或先 cd 到本目录再执行**（数据目录按"脚本所在目录"相对解析）。
账号创建、导入、建索引一律在**无认证窗口**完成，最后才换认证版启动脚本——顺序反了会因
无管理员账号而卡死（本项目踩过两次）。

## 模式一：单机（任务三、任务四）

1. 双击 `../集群配置与启动脚本/start_standalone.bat`（无认证，端口 27017）
2. 双击 `run_import_standalone.bat`（建集合 + 导入 50/30/3000，日期转 BSON Date）
3. `mongosh --port 27017 --file 02_verify.js`（数量/状态/嵌套/类型核对）
4. `mongosh --port 27017 --file 03_search.js`、`04_stats.js`（六检索、五统计）
5. `mongosh --port 27017 --file 05_index_explain.js`（建 6 索引 + explain 前后对比）
6. `mongosh --port 27017 --file 06_accounts.js`（只读/读写/管理三账号）
7. 关闭单机窗口，双击 `start_standalone_auth.bat`（启用认证）
8. ①源代码 `python main.py`：菜单 13 上传 GridFS 六文件、菜单 14 下载校验、菜单 16 日志；
   或 `python gridfs_verify.py` 一次校验全部六文件字节
9. 权限越权验证：把 config.json 的 user/password 换成 reader_acc / admin_acc 再跑 main.py，
   写入类菜单应被拒绝（截图 11、12 即此过程）

## 模式二：三节点副本集 rs0（任务五）

1. 依次双击 `start_rs_node1.bat`、`start_rs_node2.bat`、`start_rs_node3.bat`（无认证）
2. `mongosh --port 27017 --file 10_rs_init.js`（初始化 rs0，等选举）
3. `mongosh --port 27017 --file 10b_make_cluster_admin.js`（无认证窗口建 cluster_admin）
4. `mongosh --port 27017 --file 06_accounts.js`（业务三账号）
5. 双击 `run_import_standalone.bat`（27017 此时为主节点）
6. `02_verify.js` / `03_search.js` / `04_stats.js` / `05_index_explain.js`（同模式一）
7. `mongosh --port 27017 --file 12_readpref.js`（primary 与 secondaryPreferred 两种读偏好）
8. `mongosh --port 27017 --file 11_rs_status.js`（主从角色截图）
9. 应用程序上传 GridFS（同模式一第 8 步，config 保持副本集形态）
10. 关闭三个窗口，依次双击 `start_rs_node1_auth.bat` / `node2_auth` / `node3_auth`
11. `mongosh -u cluster_admin -p Cluster@2026 --authenticationDatabase admin --file 13_auth_verify.js`
12. 故障转移演练：关闭主节点窗口 → 观察从节点升主（`11_rs_status.js`）→ 重开原主窗口观察其以
    SECONDARY 回归；节点增删：双击 `start_rs_node4_temp_auth.bat` 后在主节点执行
    `rs.add("127.0.0.1:27020")`，同步完成后 `rs.remove("127.0.0.1:27020")`
    （注意：rs.add/rs.remove 只能在主节点执行，在从节点执行会被拒，截图 28）

## 模式三：分片集群（任务六）

1. 双击 `start_sh_cfg_auth.bat` → `mongosh --port 28019 --file 14_cfg_init.js`
2. 双击 `start_sh_shard1_auth.bat`、`start_sh_shard2_auth.bat`
   → `mongosh --port 28018 --file 14b_init_shards.js`（两个分片各自初始化单成员副本集）
3. 双击 `start_sh_mongos_auth.bat`（路由 28021）
4. `mongosh --port 28021 --file 15b_make_shard_admin.js`（localhost 例外窗口只允许创建第一个
   管理员账号，其余命令仍需凭据，所以必须先建 shard_admin）
5. `mongosh --port 28021 -u shard_admin -p Shard@2026 --authenticationDatabase admin --file 15_shard_setup.js`
   （添加分片、启用分片、哈希分片键）
6. 双击 `run_import_mongos.bat`（经路由导入 3000 条流水）
7. 双击 `run_shard_verify.bat`（数量核对、$collStats 两分片分布、定向 vs 跨分片 explain 对比）

## 输出存档

历史运行输出见 `../../④过程记录/执行输出/`（15_import_shard、15_shard_setup、16_shard_verify 等）。
重跑时可用 `mongosh ... --file xx.js > 输出.txt` 自行留档。

## MongoDB 7.0 实测注意事项（复跑中实际碰到）

1. `--shardsvr` 不能以单机形态启动，必须同时给 `--replSet`，否则 mongod 报
   `Cannot start a shardsvr as a standalone server` 并退出。本包两个分片都按
   单成员副本集（shard01/shard02 各 1 个节点）拉起。
2. `mongos` 没有 `--auth` 参数。路由启用认证只靠 `--keyFile`，密钥与配置服务器、
   分片节点共用同一份。
3. `config.chunks` 自 7.0 起不再记录 chunk 文档，chunk 元数据移到 config.settings 由
   内部机制维护。分布核验改用 `$collStats` 聚合（见 `run_shard_verify.bat`），
   官方视图为 `shardedDataDistribution`。
4. `localhost` 例外只允许创建**第一个**用户。分片集群因此在无认证窗口先执行
   `15b_make_shard_admin.js`，之后带凭据执行 `15_shard_setup.js`；顺序颠倒会使
   `sh.enableSharding` 之后的 config 库操作被拒绝，需要重建集群。
5. mongod 7.0 不再接受 `mongod --shutdown` 命令行选项，关闭服务用
   `db.adminCommand({ shutdown: 1 })`（客户端会抛连接中断，属正常）。
6. keyFile 路径不能含中文：mongod 读密钥走窄字符接口，中文路径报
   `Illegal byte sequence` 且只写日志、控制台无提示。用 `setup_keyfile.bat`
   建立的纯英文目录联接规避。

## 可选加固项：$jsonSchema 校验器（本包未启用）

实测过字段校验器：同一批文档分别写入带校验器与不带校验器的两个集合，四条规则
（isbn 必须 string、status 限三值、reader_card 匹配 `^R\d{8}$`、borrow_date 必须 date）
的四条违规全部在带校验器的集合被拒（code 121 Document failed validation），
不带校验器的集合六条全部写入成功。对照输出见
`../../④过程记录/执行输出/17_schema_txn_probe.txt`。

本包未在 smart_library 上启用，原因是源数据存在整字段缺失（858 条无 return_date、
4 本无 tags），规则需写成 date 与 null 的联合类型并允许缺省，任务四的写入与任务六的
导入要同步改动；字段类型已由 `01_import.js` 统一转换保证。若要启用，按上述四条规则
写一个 $jsonSchema 的 validator 对 borrow_logs 执行 `collMod` 即可，注意 collMod 的校验器
为整体替换；探测脚本本身因含绝对路径未随包分发，规则与结果以存档输出为准。
