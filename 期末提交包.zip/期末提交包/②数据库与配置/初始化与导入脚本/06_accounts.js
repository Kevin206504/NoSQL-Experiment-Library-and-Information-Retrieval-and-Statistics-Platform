// 06_accounts.js —— 任务三：创建三个账号（只读 / 读写 / 管理）
// 用法: mongosh "本目录/06_accounts.js"
// 注意：必须在“未启用 --auth”的阶段执行（当前单机即为此状态）

db = db.getSiblingDB("smart_library");

db.createUser({ user: "reader_acc", pwd: "Reader@2026", roles: [ { role: "read", db: "smart_library" } ] });
print("reader_acc（只读）创建完成");

db.createUser({ user: "writer_acc", pwd: "Writer@2026", roles: [ { role: "readWrite", db: "smart_library" } ] });
print("writer_acc（读写）创建完成");

db.createUser({ user: "admin_acc", pwd: "Admin@2026",
  roles: [ { role: "dbAdmin", db: "smart_library" }, { role: "userAdmin", db: "smart_library" } ] });
print("admin_acc（管理）创建完成");

print("\n===== 当前账号清单 =====");
db.getUsers().users.forEach(u => print("  " + u.user + "  角色: " + JSON.stringify(u.roles.map(r => r.role))));
