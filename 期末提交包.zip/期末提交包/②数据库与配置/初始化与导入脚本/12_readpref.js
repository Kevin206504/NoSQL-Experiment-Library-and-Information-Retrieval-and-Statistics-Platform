// 12_readpref.js —— 任务五：两种读取偏好对比验证（演练模式，无认证）
// 用法: mongosh "本目录/12_readpref.js"
// 用不同 readPreference 各建一条连接，观察实际由哪个节点服务读请求。

const BASE = "mongodb://127.0.0.1:27017,127.0.0.1:27018,127.0.0.1:27019/?replicaSet=rs0";

print("===== 读取偏好 1：primary（默认，主节点读）=====");
const c1 = new Mongo(BASE + "&readPreference=primary");
const d1 = c1.getDB("smart_library");
const h1 = d1.hello();
print("  读请求由 " + h1.me + " 服务，isWritablePrimary=" + h1.isWritablePrimary);
print("  样例: " + JSON.stringify(d1.books.findOne({}, { _id: 0, isbn: 1 })));
print("  适用场景：要求数据最新（如管理后台、写后即读）");

print("\n===== 读取偏好 2：secondaryPreferred（优先从节点读）=====");
const c2 = new Mongo(BASE + "&readPreference=secondaryPreferred");
const d2 = c2.getDB("smart_library");
const h2 = d2.hello();
print("  读请求由 " + h2.me + " 服务，isWritablePrimary=" + h2.isWritablePrimary);
print("  样例: " + JSON.stringify(d2.books.findOne({}, { _id: 0, isbn: 1 })));
print("  适用场景：读多写少、可容忍轻微延迟（如统计报表、前台查询分流）");
