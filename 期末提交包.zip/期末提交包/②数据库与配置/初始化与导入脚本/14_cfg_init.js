// 14_cfg_init.js —— 任务六：初始化配置服务器副本集 cfgReplSet
// 用法（start_sh_cfg.bat 已启动后）: mongosh --port 28019 "本目录/14_cfg_init.js"

print("== 初始化配置服务器副本集 cfgReplSet（28019）==");
const r = rs.initiate({
  _id: "cfgReplSet",
  configsvr: true,
  members: [ { _id: 0, host: "127.0.0.1:28019" } ],
});
printjson(r);
sleep(5000);
print("配置服务器角色: " + db.hello().me + "  PRIMARY=" + db.hello().isWritablePrimary);
