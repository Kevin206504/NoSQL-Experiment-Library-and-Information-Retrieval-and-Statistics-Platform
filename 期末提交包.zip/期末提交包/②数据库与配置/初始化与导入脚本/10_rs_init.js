// 10_rs_init.js —— 任务五：初始化三节点副本集 rs0（演练模式，无认证）
// 用法（三个无认证节点均已启动后，直接粘贴运行，无需账号）:
//   mongosh "本目录/10_rs_init.js"

print("== 初始化副本集 rs0（27017 / 27018 / 27019）==");
const result = rs.initiate({
  _id: "rs0",
  members: [
    { _id: 0, host: "127.0.0.1:27017" },
    { _id: 1, host: "127.0.0.1:27018" },
    { _id: 2, host: "127.0.0.1:27019" },
  ],
});
printjson(result);
print("等待选举完成（约 10 秒）…");
sleep(10000);
const hello = db.hello();
print("当前主节点: " + hello.primary);
rs.status().members.forEach(m =>
  print("  " + m.name + "  state=" + m.stateStr));
