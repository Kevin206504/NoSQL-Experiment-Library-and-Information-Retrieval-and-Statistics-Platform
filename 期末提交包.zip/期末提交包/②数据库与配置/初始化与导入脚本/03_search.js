// 03_search.js —— 任务三：6 项检索功能（含结果条数与基线核对）
// 用法: mongosh "本目录/03_search.js"

db = db.getSiblingDB("smart_library");

function check(no, desc, expected, actual) {
  const ok = (expected === actual) ? "✓" : "✗ 与基线不符";
  print("【" + no + "】" + desc + "  => " + actual + " 条（基线 " + expected + "）" + ok);
}

// F1 按类别与价格区间组合筛选
check("F1", "计算机类且价格在 40—100 元", 10,
  db.books.find({ category: "计算机", price: { $gte: 40, $lte: 100 } }).count());

// F2 按标签多选匹配（同时含多个指定标签）
check("F2", "标签同时含「编程」和「入门」($all)", 1,
  db.books.find({ tags: { $all: ["编程", "入门"] } }).count());

// F3 按书名模糊检索
check("F3", "书名含「数据」($regex)", 3,
  db.books.find({ title: { $regex: "数据" } }).count());

// F4 按出版年份范围检索（2020—2023 年）
check("F4", "出版年份在 2020—2023 年", 9,
  db.books.find({ publish_date: { $gte: new Date("2020-01-01T00:00:00+08:00"),
                                   $lte: new Date("2023-12-31T23:59:59+08:00") } }).count());

// F5 查询缺少 tags 字段的图书（数据质量核查）
check("F5", "缺少 tags 字段（$exists:false）", 4,
  db.books.find({ tags: { $exists: false } }).count());

// F6 按评分排序取前 10，仅返回书名、作者、评分（投影）
print("【F6】按评分排序取前 10（投影：书名/作者/评分）：");
const top10 = db.books.find({}, { _id: 0, title: 1, author: 1, rating: 1 })
  .sort({ rating: -1 }).limit(10).toArray();
top10.forEach((d, i) => print("  No." + (i + 1) + " " + d.title + " / " + d.author + " / " + d.rating));
print("  注：4.7 分存在多本并列，末位名次受并列影响（数据均匀生成的特性）");
