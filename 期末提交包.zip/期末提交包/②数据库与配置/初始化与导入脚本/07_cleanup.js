// 07_cleanup.js —— 清理权限验证误操作产生的脏数据（认证开启前执行）
// 用法: mongosh "本目录/07_cleanup.js"

db = db.getSiblingDB("smart_library");

print("== 1. 清理 books 中误插入的测试文档 ==");
const r1 = db.books.deleteMany({ t: 1 });
print("  删除 " + r1.deletedCount + " 条，books 现有 " + db.books.countDocuments({}) + " 条（期望 50）");

print("\n== 2. 清理误创建的空角色用户 x ==");
if (db.getUser("x")) {
  db.dropUser("x");
  print("  用户 x 已删除");
} else {
  print("  用户 x 不存在，无需清理");
}

print("\n== 3. 复核 ==");
print("  books = " + db.books.countDocuments({}) + " / readers = " + db.readers.countDocuments({})
  + " / borrow_logs = " + db.borrow_logs.countDocuments({}));
print("  剩余用户: " + db.getUsers().users.map(u => u.user).join(", "));
