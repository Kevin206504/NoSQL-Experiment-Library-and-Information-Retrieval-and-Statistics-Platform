// 16_shard_verify.js —— 任务六：分片分布验证 + 定向/跨分片查询对比（经 mongos）
// 用法（数据已导入后）: mongosh --port 28021 "本目录/16_shard_verify.js"

db = db.getSiblingDB("smart_library");

print("===== 1. 数量核对（经 mongos 导入后）=====");
print("books = " + db.books.countDocuments({}) + "（期望 50）");
print("readers = " + db.readers.countDocuments({}) + "（期望 30）");
print("borrow_logs = " + db.borrow_logs.countDocuments({}) + "（期望 3000）");

print("\n===== 2. borrow_logs 分片分布（$collStats 每分片文档数）=====");
const dist = db.borrow_logs.aggregate([ { $collStats: { count: {} } },
  { $project: { _id: 0, shard: 1, docs: "$count" } } ]).toArray();
let total = 0;
dist.forEach(d => { print("  分片 " + d.shard + "：" + d.docs + " 条"); total += d.docs; });
print("  合计 " + total + " 条，分布在 " + dist.length + " 个分片上"
  + (dist.length >= 2 ? " ✓（数据确实分布于多个分片）" : " ✗ 未分布！"));

print("\n===== 3. chunk 元数据说明 =====");
print("  MongoDB 7.0 起 chunk 不再记录于 config.chunks（元数据机制变更），");
print("  分片分布以第 2 节 $collStats 实测为准，均衡状态可用 sh.status()/getShardDistribution 观察。");

print("\n===== 4. 定向查询 vs 跨分片查询（explain 对比）=====");
function analyze(e) {
  const w = e.queryPlanner.winningPlan;
  const s = e.executionStats || {};
  let n = 1, shards = "-";
  if (w.shards) {
    n = w.shards.length;
    shards = w.shards.map(x => x.shardName).join(",");
  }
  const s2 = e.executionStats || {};
  return { n: n, shards: shards, docs: s2.totalDocsExamined || 0,
           ret: s2.nReturned || 0, ms: s2.executionTimeMillis || 0 };
}
const t1 = db.borrow_logs.find({ reader_card: "R20240001" }).explain("executionStats");
const t2 = db.borrow_logs.find({ status: "借出" }).explain("executionStats");
const a1 = analyze(t1), a2 = analyze(t2);
print("  定向查询 { reader_card: 'R20240001' }（命中分片键）: 访问 " + a1.n + " 个分片"
  + "（" + a1.shards + "），检查文档=" + a1.docs + "，返回=" + a1.ret);
print("  跨分片查询 { status: '借出' }（未含分片键）: 访问 " + a2.n + " 个分片"
  + "（" + a2.shards + "），检查文档=" + a2.docs + "，返回=" + a2.ret);
print("  结论: 含分片键的等值查询只路由到 1 个分片；不含分片键的查询广播到全部分片");
