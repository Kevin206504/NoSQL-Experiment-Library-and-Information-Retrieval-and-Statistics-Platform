// 14b_init_shards.js —— 任务六：初始化两个分片各自的单成员副本集
// 用法（shard1/shard2 已启动、mongos 添加分片之前）:
//   mongosh --port 28018 --file 14b_init_shards.js   （脚本内会依次连两个分片）
// 说明：--shardsvr 必须与 --replSet 同用，且分片必须先 rs.initiate 才能被 sh.addShard 接受。

const s1 = new Mongo("127.0.0.1:28018");
print("== 初始化 shard01 ==");
printjson(s1.getDB("admin").runCommand({
  replSetInitiate: { _id: "shard01", members: [ { _id: 0, host: "127.0.0.1:28018" } ] } }));
const s2 = new Mongo("127.0.0.1:28020");
print("== 初始化 shard02 ==");
printjson(s2.getDB("admin").runCommand({
  replSetInitiate: { _id: "shard02", members: [ { _id: 0, host: "127.0.0.1:28020" } ] } }));
sleep(5000);
print("shard01 PRIMARY=" + s1.getDB("admin").runCommand({ hello: 1 }).isWritablePrimary);
print("shard02 PRIMARY=" + s2.getDB("admin").runCommand({ hello: 1 }).isWritablePrimary);