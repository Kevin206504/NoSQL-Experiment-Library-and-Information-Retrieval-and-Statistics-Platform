// 15_shard_setup.js —— 任务六：添加分片、启用分片、选择分片键（经 mongos 执行）
// 用法（cfg/shard1/shard2/mongos 四个组件均已启动后）:
//   mongosh --port 28021 "本目录/15_shard_setup.js"

print("== 1. 添加两个分片（单成员副本集形式）==");
printjson(sh.addShard("shard01/127.0.0.1:28018"));
printjson(sh.addShard("shard02/127.0.0.1:28020"));

print("\n== 2. 分片集群状态 ==");
sh.status();

print("\n== 3. 对 smart_library 启用分片 ==");
printjson(db.adminCommand({ enableSharding: "smart_library" }));

print("\n== 4. 为 borrow_logs 建立分片键索引并启用分片（分片键: reader_card 哈希）==");
db = db.getSiblingDB("smart_library");
db.borrow_logs.createIndex({ reader_card: "hashed" });
printjson(db.adminCommand({ shardCollection: "smart_library.borrow_logs", key: { reader_card: "hashed" } }));
print("分片键: { reader_card: 'hashed' }（选择论证见技术文档 6.2 节）");
print("\n== 完成。接下来经 mongos 导入数据（01_import.js --port 28021）==");
