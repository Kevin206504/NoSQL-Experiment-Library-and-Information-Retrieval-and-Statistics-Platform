// 02_verify.js —— 任务三：导入后的数据核对（数量 + 类型 + 抽样）
// 用法: mongosh "本目录/02_verify.js"

db = db.getSiblingDB("smart_library");

print("===== 1. 文档数量核对 =====");
print("books       = " + db.books.countDocuments({}) + "（期望 50）");
print("readers     = " + db.readers.countDocuments({}) + "（期望 30）");
print("borrow_logs = " + db.borrow_logs.countDocuments({}) + "（期望 3000）");

print("\n===== 2. 借阅状态分布（期望 已归还2142/借出429/逾期429）=====");
db.borrow_logs.aggregate([{ $group: { _id: "$status", n: { $sum: 1 } } }, { $sort: { _id: 1 } }])
  .forEach(d => print("  " + d._id + ": " + d.n));

print("\n===== 3. 嵌套文档 location 抽样（books.location 为嵌套文档的证据）=====");
const b1 = db.books.findOne({ isbn: "9787115428028" }, { _id: 0, isbn: 1, title: 1, location: 1, ebook_name: 1 });
printjson(b1);
print("location 类型: " + typeof b1.location + "（object 即嵌套文档）");

print("\n===== 4. 字段类型抽样 =====");
const l1 = db.borrow_logs.findOne({}, { _id: 0, borrow_date: 1, duration_days: 1 });
print("borrow_date 类型: " + l1.borrow_date.constructor.name + "（应为 Date，值: " + l1.borrow_date.toISOString().substring(0, 10) + "）");
print("duration_days 类型: " + typeof l1.duration_days + "（应为 number/BSON int，值: " + l1.duration_days + "）");

print("\n===== 5. 数据不齐情况核查（真实业务常见）=====");
print("books 无 tags 字段: " + db.books.countDocuments({ tags: { $exists: false } }) + " 条");
print("readers 无 fav_categories: " + db.readers.countDocuments({ fav_categories: { $exists: false } }) + " 条");
print("books 带 ebook_name（可关联 GridFS）: " + db.books.countDocuments({ ebook_name: { $exists: true } }) + " 条");

print("\n===== 6. 日期范围 =====");
const dr = db.borrow_logs.aggregate([
  { $group: { _id: null, min: { $min: "$borrow_date" }, max: { $max: "$borrow_date" } } }
]).toArray()[0];
print("borrow_logs: " + dr.min.toISOString().substring(0, 10) + " ~ " + dr.max.toISOString().substring(0, 10) + "（期望 2023-01-01 ~ 2025-12-28）");

print("\n===== 7. 类别分布（6 类）=====");
db.books.aggregate([{ $sortByCount: "$category" }]).forEach(d => print("  " + d._id + ": " + d.count));

print("\n===== 核对完成 =====");
