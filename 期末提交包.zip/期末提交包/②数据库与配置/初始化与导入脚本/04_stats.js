// 04_stats.js —— 任务三：5 项统计功能（含 $merge 落库）
// 用法: mongosh "本目录/04_stats.js"

db = db.getSiblingDB("smart_library");
const TZ = "+08:00";   // 显式时区：避免跨年/跨月边界记录被算进错误年份（ISO 字符串按 +08:00 存储）

print("===== S1 按类别统计藏书量、平均价格、平均评分 =====");
const catRows = db.books.aggregate([
  { $group: { _id: "$category", stock_total: { $sum: "$stock" },
              book_count: { $sum: 1 },
              avg_price: { $avg: "$price" }, avg_rating: { $avg: "$rating" } } },
  { $project: { _id: 0, category: "$_id", stock_total: 1, book_count: 1,
                avg_price: { $round: ["$avg_price", 2] }, avg_rating: { $round: ["$avg_rating", 2] } } },
  { $sort: { book_count: -1 } }
]).toArray();
catRows.forEach(r => print("  " + r.category + "：藏书 " + r.book_count + " / 库存 " + r.stock_total
  + " / 均价 " + r.avg_price + " / 均分 " + r.avg_rating));
print("  基线：计算机15/文学12/经管7/数学6/外语5/历史5");

print("\n===== S2 各学院借阅总量 TOP5（$lookup 关联读者表）=====");
const collegeRows = db.borrow_logs.aggregate([
  { $group: { _id: "$reader_card", borrows: { $sum: 1 } } },
  { $lookup: { from: "readers", localField: "_id", foreignField: "card_no", as: "reader" } },
  { $unwind: "$reader" },
  { $group: { _id: "$reader.college", total: { $sum: "$borrows" } } },
  { $project: { _id: 0, college: "$_id", total: 1 } },
  { $sort: { total: -1 } }, { $limit: 5 }
]).toArray();
collegeRows.forEach((r, i) => print("  No." + (i + 1) + " " + r.college + "：" + r.total + " 次"));
print("  基线：计算机学院500 / 经管学院500 / 文学院400 / 数学与统计400 / 管理400");

print("\n===== S3 按年月统计借阅趋势（$dateToString + timezone）=====");
const trend = db.borrow_logs.aggregate([
  { $group: { _id: { $dateToString: { format: "%Y年%m月", date: "$borrow_date", timezone: TZ } },
              count: { $sum: 1 } } },
  { $sort: { _id: 1 } }
]).toArray();
trend.forEach(r => print("  " + r._id + "：" + r.count + " 本"));
print("  共 " + trend.length + " 个月份标签（基线 36 个，2023—2025 每年 12 个月）");

print("\n===== S4 借阅次数最多的 10 本图书（$lookup 关联馆藏位置）=====");
const topBooks = db.borrow_logs.aggregate([
  { $group: { _id: "$book_isbn", borrow_times: { $sum: 1 } } },
  { $sort: { borrow_times: -1 } }, { $limit: 10 },
  { $lookup: { from: "books", localField: "_id", foreignField: "isbn", as: "book" } },
  { $unwind: "$book" },
  { $project: { _id: 0, title: "$book.title", floor: "$book.location.floor",
                shelf: "$book.location.shelf", borrow_times: 1 } },
  { $sort: { borrow_times: -1 } }
]).toArray();
topBooks.forEach((r, i) => print("  No." + (i + 1) + " " + r.title + "：" + r.borrow_times
  + " 次 @ " + r.floor + " " + r.shelf));
print("  注：数据均匀生成，10 本并列 60 次（并列排序现象的又一例证）");

print("\n===== S5 分类统计结果写入 category_stats（$merge 落库）=====");
db.category_stats.drop();
db.books.aggregate([
  { $group: { _id: "$category", book_count: { $sum: 1 },
              avg_price_raw: { $avg: "$price" },
              avg_rating_raw: { $avg: "$rating" },
              stock_total: { $sum: "$stock" } } },
  { $project: { avg_price: { $round: ["$avg_price_raw", 2] },
                avg_rating: { $round: ["$avg_rating_raw", 2] },
                book_count: 1, stock_total: 1 } },
  { $merge: { into: "category_stats" } }
]);
print("  落库完成，category_stats 共 " + db.category_stats.countDocuments({}) + " 条：");
db.category_stats.find().forEach(d => printjson(d));
