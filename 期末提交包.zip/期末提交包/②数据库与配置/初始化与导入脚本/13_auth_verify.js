// 13_auth_verify.js —— 任务五：启用认证后的副本集验证（用集群管理员登录）
// 用法（三个认证版节点已启动后）:
//   mongosh -u cluster_admin -p "Cluster@2026" --authenticationDatabase admin "本目录/13_auth_verify.js"

print("== 认证生效确认 ==");
print("  已以 cluster_admin（root）成功认证登录副本集 ✓");

print("\n== 副本集状态（认证模式下）==");
const hello = db.hello();
print("  主节点: " + hello.primary);
rs.status().members.forEach(m => print("  " + m.name + "  state=" + m.stateStr));

print("\n== 数据完整性（升级副本集后无丢失）==");
print("  books = " + db.getSiblingDB("smart_library").books.countDocuments({}) + "（期望 50）");
print("  borrow_logs = " + db.getSiblingDB("smart_library").borrow_logs.countDocuments({}) + "（期望 3000）");
print("  GridFS fs.files = " + db.getSiblingDB("smart_library")["fs.files"].countDocuments({}) + "（期望 6）");

print("\n== 既有业务账号仍然可用（authSource=smart_library）==");
const w = new Mongo("mongodb://writer_acc:Writer@2026@127.0.0.1:27017/?authSource=smart_library&replicaSet=rs0");
const wd = w.getDB("smart_library");
print("  writer_acc 读: " + (wd.books.findOne() ? "成功 ✓" : "失败"));
